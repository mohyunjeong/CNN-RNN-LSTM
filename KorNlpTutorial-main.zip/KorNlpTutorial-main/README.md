# KorNlpTutorial   
한국어 자연어처리 튜토리얼   
PPT 파일: https://drive.google.com/file/d/120EZH-LSJdmod3JOuyf0dziQaAFbXkQe/view?usp=sharing    
